# site

![Vercel](https://img.shields.io/github/deployments/fabe/site/production?logo=vercel&logoColor=white&label=Vercel)
[![GitHub license](https://img.shields.io/github/license/fabe/site)](https://github.com/fabe/site/blob/main/license)

This is the source code of [my website](https://fabianschultz.com).

## Installation

    $ git clone git@github.com:fabe/site.git
    $ cd site
    $ yarn
    $ yarn dev
